module hy360_us {
	requires java.sql;
	requires java.desktop;
}